﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CalculateorPract
{
    public partial class MainWindow : Window
    {
        private readonly Dictionary<string, int> operatorPrecedence;
        private const double PI = Math.PI;
        private const double E = Math.E;

        public MainWindow()
        {
            InitializeComponent();
            AttachButtonHandlers();

            operatorPrecedence = new Dictionary<string, int>
            {
                { "+", 1 }, { "-", 1 },
                { "*", 2 }, { "/", 2 },
                { "^", 3 }, { "√", 3 },
                { "sin", 4 }, { "cos", 4 }, { "tg", 4 },
                { "log", 4 }, { "ln", 4 },
                { "!", 5 }
            };
        }

        private void AttachButtonHandlers()
        {
            var buttonsGrid = (Grid)((Grid)Content).Children[2];
            foreach (Button button in buttonsGrid.Children)
            {
                button.Click += Button_Click;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var button = (Button)sender;
            var content = button.Content.ToString();

            switch (content)
            {
                case "CE":
                    ExpressionTextBlock.Text = string.Empty;
                    ResultTextBlock.Text = "0";
                    break;

                case "⌫":
                    if (!string.IsNullOrEmpty(ExpressionTextBlock.Text))
                    {
                        ExpressionTextBlock.Text = ExpressionTextBlock.Text.Substring(0, ExpressionTextBlock.Text.Length - 1);
                    }
                    break;

                case "=":
                    try
                    {
                        var result = EvaluateExpression(ExpressionTextBlock.Text);
                        ResultTextBlock.Text = result.ToString("G10");
                    }
                    catch (DivideByZeroException)
                    {
                        ResultTextBlock.Text = "деление на ноль!";
                    }
                    catch (Exception ex)
                    {
                        ResultTextBlock.Text = $"Ошибка: {ex.Message}";
                    }
                    break;

                default:
                    // Handle numeric buttons and operators
                    switch (content)
                    {
                        case "sin":
                            ExpressionTextBlock.Text += "sin(";
                            break;
                        case "cos":
                            ExpressionTextBlock.Text += "cos(";
                            break;
                        case "tg":
                            ExpressionTextBlock.Text += "tg(";
                            break;
                        case "π":
                            ExpressionTextBlock.Text += "π";
                            break;
                        case "e":
                            ExpressionTextBlock.Text += "e";
                            break;
                        case "x²":
                            ExpressionTextBlock.Text += "^2";
                            break;
                        case "1/x":
                            ExpressionTextBlock.Text += "1/";
                            break;
                        case "|x|":
                            ExpressionTextBlock.Text += "|";
                            break;
                        case "√x":
                            ExpressionTextBlock.Text += "√";
                            break;
                        case "x^y":
                            ExpressionTextBlock.Text += "^";
                            break;
                        case "10^x":
                            ExpressionTextBlock.Text += "10^";
                            break;
                        case "log":
                            ExpressionTextBlock.Text += "log(";
                            break;
                        case "ln":
                            ExpressionTextBlock.Text += "ln(";
                            break;
                        case "n!":
                            ExpressionTextBlock.Text += "!";
                            break;
                        case "+/-":
                            if (!string.IsNullOrEmpty(ExpressionTextBlock.Text))
                            {
                                if (ExpressionTextBlock.Text[0] == '-')
                                    ExpressionTextBlock.Text = ExpressionTextBlock.Text.Substring(1);
                                else
                                    ExpressionTextBlock.Text = "-" + ExpressionTextBlock.Text;
                            }
                            break;
                        default:
                            if (content == "×")
                                ExpressionTextBlock.Text += "*";
                            else if (content == "÷")
                                ExpressionTextBlock.Text += "/";
                            else
                                ExpressionTextBlock.Text += content;
                            break;
                    }
                    break;
            }
        }

        private double EvaluateExpression(string expression)
        {
            var tokens = TokenizeExpression(expression);
            var postfix = ShuntingYard(tokens);
            return EvaluatePostfix(postfix);
        }

        private List<string> TokenizeExpression(string expression)
        {
            var tokens = new List<string>();
            var currentToken = "";

            for (int i = 0; i < expression.Length; i++)
            {
                var c = expression[i];

                if (char.IsDigit(c) || c == ',' || c == 'π' || c == 'e')
                {
                    currentToken += c;
                }
                else if (c == '-' && (i == 0 || expression[i - 1] == '('))
                {
                    currentToken += c;
                }
                else if (IsOperator(c.ToString()) || c == '(' || c == ')')
                {
                    if (!string.IsNullOrEmpty(currentToken))
                    {
                        tokens.Add(currentToken);
                        currentToken = "";
                    }
                    tokens.Add(c.ToString());
                }
                else if (char.IsLetter(c))
                {
                    currentToken += c;
                    if (IsFunction(currentToken))
                    {
                        tokens.Add(currentToken);
                        currentToken = "";
                    }
                }
            }

            if (!string.IsNullOrEmpty(currentToken))
            {
                tokens.Add(currentToken);
            }

            return tokens;
        }

        private List<string> ShuntingYard(List<string> tokens)
        {
            var output = new List<string>();
            var operatorStack = new Stack<string>();

            foreach (var token in tokens)
            {
                if (IsNumber(token))
                {
                    output.Add(token);
                }
                else if (IsFunction(token))
                {
                    operatorStack.Push(token);
                }
                else if (token == "(")
                {
                    operatorStack.Push(token);
                }
                else if (token == ")")
                {
                    while (operatorStack.Count > 0 && operatorStack.Peek() != "(")
                    {
                        output.Add(operatorStack.Pop());
                    }
                    if (operatorStack.Count > 0 && operatorStack.Peek() == "(")
                    {
                        operatorStack.Pop();
                    }
                    if (operatorStack.Count > 0 && IsFunction(operatorStack.Peek()))
                    {
                        output.Add(operatorStack.Pop());
                    }
                }
                else if (IsOperator(token))
                {
                    while (operatorStack.Count > 0 && operatorStack.Peek() != "(" &&
                           operatorPrecedence.ContainsKey(operatorStack.Peek()) &&
                           operatorPrecedence[operatorStack.Peek()] >= operatorPrecedence[token])
                    {
                        output.Add(operatorStack.Pop());
                    }
                    operatorStack.Push(token);
                }
            }

            while (operatorStack.Count > 0)
            {
                output.Add(operatorStack.Pop());
            }

            return output;
        }

        private double EvaluatePostfix(List<string> postfix)
        {
            var stack = new Stack<double>();

            foreach (var token in postfix)
            {
                if (IsNumber(token))
                {
                    stack.Push(ParseNumber(token));
                }
                else if (IsOperator(token) || IsFunction(token))
                {
                    var result = EvaluateOperation(token, stack);
                    stack.Push(result);
                }
            }

            return stack.Pop();
        }

        private double ParseNumber(string token)
        {
            if (token == "π") return PI;
            if (token == "e") return E;
            return double.Parse(token);
        }

        private bool IsNumber(string token)
        {
            return double.TryParse(token, out _) || token == "π" || token == "e";
        }

        private bool IsOperator(string token)
        {
            return operatorPrecedence.ContainsKey(token);
        }

        private bool IsFunction(string token)
        {
            return new[] { "sin", "cos", "tg", "log", "ln" }.Contains(token);
        }

        private double EvaluateOperation(string operation, Stack<double> stack)
        {
            double b, a;
            switch (operation)
            {
                case "+":
                    b = stack.Pop();
                    a = stack.Pop();
                    return a + b;
                case "-":
                    b = stack.Pop();
                    a = stack.Pop();
                    return a - b;
                case "*":
                    b = stack.Pop();
                    a = stack.Pop();
                    return a * b;
                case "/":
                    b = stack.Pop();
                    if (Math.Abs(b) < double.Epsilon)
                        throw new DivideByZeroException();
                    a = stack.Pop();
                    return a / b;
                case "^":
                    b = stack.Pop();
                    a = stack.Pop();
                    return Math.Pow(a, b);
                case "√":
                    a = stack.Pop();
                    if (a < 0)
                        throw new ArgumentException("Невозможно извлечь квадратный корень из отрицательного числа");
                    return Math.Sqrt(a);
                case "!":
                    a = stack.Pop();
                    if (a < 0 || a != Math.Floor(a))
                        throw new ArgumentException("Факториал определен только для неотрицательных целых чисел");
                    return Factorial((int)a);
                case "sin":
                    return Math.Sin(stack.Pop());
                case "cos":
                    return Math.Cos(stack.Pop());
                case "tg":
                    return Math.Tan(stack.Pop());
                case "log":
                    a = stack.Pop();
                    if (a <= 0)
                        throw new ArgumentException("Логарифм определен только для положительных чисел");
                    return Math.Log10(a);
                case "ln":
                    a = stack.Pop();
                    if (a <= 0)
                        throw new ArgumentException("Логарифм определен только для положительных чисел");
                    return Math.Log(a);
                default:
                    throw new ArgumentException($"Неизвестная операция: {operation}");
            }
        }

        private double Factorial(int n)
        {
            if (n > 170)
                throw new ArgumentException("Слишком большое число для вычисления факториала");
            double result = 1;
            for (int i = 2; i <= n; i++)
                result *= i;
            return result;
        }
    }
}